@extends('layouts.app')

@section('content')
登録を完了しました！

@endsection