<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('登録内容の確認')); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('create')); ?>">
                        <?php echo csrf_field(); ?>

                        name: <?php echo e($user['name']); ?><br />
                        furigana: <?php echo e($user['furigana']); ?><br />
                        phone: <?php echo e($user['phone']); ?><br />
                        email: <?php echo e($user['email']); ?><br />
                        

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('登録')); ?>

                                </button>
                            </div>
                        </div>

                       

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\m-yokoyama\Desktop\20200109login\200113login\resources\views/auth/confirm.blade.php ENDPATH**/ ?>